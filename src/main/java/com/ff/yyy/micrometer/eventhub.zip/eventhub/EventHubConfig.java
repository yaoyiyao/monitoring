package com.ff.yyy.micrometer.eventhub;

import com.microsoft.azure.eventhubs.*;
import com.microsoft.azure.eventprocessorhost.EventProcessorHost;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@Configuration
@Profile("!test")
public class EventHubConfig {
  private AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider;

  public EventHubConfig(AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider) {
    this.azureActiveDirectoryTokenProvider = azureActiveDirectoryTokenProvider;
  }

  @Bean
  @Qualifier("eventHubExecutor")
  ScheduledExecutorService scheduledExecutorService() {
    return Executors.newScheduledThreadPool(4);
  }

  @Bean
  @Qualifier("massloadEventHub")
  public EventHubClient massloadEventHub(ScheduledExecutorService executor,
                                         AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider)
      throws URISyntaxException, IOException, EventHubException, ExecutionException, InterruptedException {
    return EventHubClient.createWithTokenProvider(new URI("https://flcit-southcentralus-non-prod-eventhub.servicebus.windows.net/"), "inventory-dev-mass-snapshot", azureActiveDirectoryTokenProvider, executor, getEventHubClientOptions()).get();
  }

  @Bean
  public EventProcessorHost createEventProcessorHost() throws URISyntaxException {
    String consumerGroupName = "$Default";
    String storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=inventoryservice;AccountKey=769p4837QJTfN6ZGrvR5a6if3Dqaw562l3Tl8bIgNoeit+zFyFiGHKJgOvSzSanBpPzktZjbVzZPQBPRk0V/xw==;EndpointSuffix=core.windows.net";
    String storageContainerName = "inventory-dev-mass-snapshot";
    String hostNamePrefix = "xom";
    String namespace = "https://flcit-southcentralus-non-prod-eventhub.servicebus.windows.net/";
    String massload = "inventory-dev-mass-snapshot";

    return EventProcessorHost.EventProcessorHostBuilder
            .newBuilder(EventProcessorHost.createHostName(hostNamePrefix), consumerGroupName)
            .useAzureStorageCheckpointLeaseManager(storageConnectionString, storageContainerName, null)
            .useAADAuthentication(new URI(namespace), massload)
            .useTokenProvider(azureActiveDirectoryTokenProvider)
            .build();
  }


  EventHubClientOptions getEventHubClientOptions() {
    EventHubClientOptions options = new EventHubClientOptions();
    options.setTransportType(TransportType.AMQP_WEB_SOCKETS);
    return options;
  }
}
