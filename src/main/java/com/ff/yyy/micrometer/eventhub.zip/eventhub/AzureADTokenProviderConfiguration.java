package com.ff.yyy.micrometer.eventhub;

import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import com.microsoft.azure.eventhubs.AzureActiveDirectoryTokenProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.Collections;
import java.util.concurrent.CompletableFuture;

@Configuration
@Profile("!test")
public class AzureADTokenProviderConfiguration {

  private String clientId = "42eff33d-6bd4-4785-abe5-67cd8054f77c";

  private String clientSecret = "Yy-j6Manf?Ryelgl2ZdolV8TWiZ0f=o-";

  private String authority = "https://login.windows.net/d1ee1acd-bc7a-4bc4-a787-938c49a83906";

  @Bean
  public AuthCallback authCallback() {
    return new AuthCallback(clientId, clientSecret);
  }

  @Bean
  public AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider(AuthCallback authCallback) {
    return new AzureActiveDirectoryTokenProvider(authCallback, authority, null);
  }

  class AuthCallback implements AzureActiveDirectoryTokenProvider.AuthenticationCallback {
    private String clientId;
    private String clientSecret;

    public AuthCallback(final String clientId, final String clientSecret) {
      this.clientId = clientId;
      this.clientSecret = clientSecret;
    }

    @Override
    public CompletableFuture<String> acquireToken(String audience, String authority, Object state) {
      try {
        ConfidentialClientApplication app = ConfidentialClientApplication.builder(this.clientId, ClientCredentialFactory.createFromSecret(this.clientSecret))
            .authority(authority)
            .build();
        ClientCredentialParameters parameters = ClientCredentialParameters.builder(Collections.singleton(audience + ".default")).build();
        return app.acquireToken(parameters).thenApply(IAuthenticationResult::accessToken);
      } catch (Exception e) {
        CompletableFuture<String> failed = new CompletableFuture<>();
        failed.completeExceptionally(e);
        return failed;
      }
    }
  }
}
