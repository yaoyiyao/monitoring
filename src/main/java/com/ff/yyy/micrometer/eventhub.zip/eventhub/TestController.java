package com.ff.yyy.micrometer.eventhub;

import com.microsoft.azure.eventprocessorhost.EventProcessorHost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
  @Autowired
  private EventProcessorHost eventProcessorHost;

  @GetMapping("/start")
  public String start() {
    eventProcessorHost.registerEventProcessor(EventProcessor.class);
    return eventProcessorHost.getHostName();
  }

  @GetMapping("/stop")
  public String stop() {
    eventProcessorHost.unregisterEventProcessor();
    return eventProcessorHost.getHostName();
  }
}